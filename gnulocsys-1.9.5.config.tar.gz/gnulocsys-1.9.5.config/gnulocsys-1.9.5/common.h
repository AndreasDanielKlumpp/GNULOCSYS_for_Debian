#ifndef COMMON_H
#define COMMON_H

#include <QString>

class Common
{
public:
    static QString datab;
};



#endif // COMMON_H
